<?php
session_start();

define('SITE_ROOT', "../../");	

define('WWW_ROOT', SITE_ROOT . 'public/');
define('DATA_DIR', SITE_ROOT . 'data/');
define('TPL_DIR', SITE_ROOT . 'templates/');
define('ENG_DIR', SITE_ROOT . 'engine/');

/* DB config */
define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB', 'geek_brains_shop');

require_once(ENG_DIR . 'functions.php');
require_once(ENG_DIR . 'db.php');
?>
