<?php
require_once('../config/config.php');

$id = '';
$alert = '';
$userName = '';
$sql = '';
$result = '';

if (!empty($_GET['id'])) {
	$id = $_GET['id'];
	$userName = $_SESSION['user']['login'];
	$sql = "DELETE FROM `basket_" . $userName . "` WHERE `id` = '$id'";
	$result = executeQuery($sql);
} else {
	$alert = 'Идентификатор товара не передан';
}

if ($result) {
	$alert = 'Товар удален';
} else {
	$alert = 'Произошла ошибка';
}

echo $alert;

?>