<?php
require_once('../config/config.php');

if(!empty($_POST['login']) && !empty($_POST['password'])) {
	$login = $_POST['login'];

	$password = md5($_POST['password']);
	$user = getAssocResult("SELECT * FROM `users` WHERE login = '$login' AND password = '$password'");
	
	if(isset($user[0])) {
		$_SESSION['user'] = $user[0];
//		header('Location: personalArea.php');
		echo "true";
	} else {
		echo "Логин или пароль не верны."; 
	}
} else {
	echo "Параметры не переданы."; 
}
?>