<?php
require_once('../config/config.php');

$userName = '';
$sql = '';
$basket = '';
$user = '';
$details = '';
$total = 0;
$date = date('Y-m-d');
$result = '';
$result_1 = '';

if (!empty($_GET['userName'])) {
	$userName = $_GET['userName'];
	$sql = "SELECT * FROM `basket_" . $userName . "`";
	$basket = getAssocResult($sql);

	$sql = "SELECT `id` FROM `users` WHERE `login` = '" . $userName . "'";
	$user = getAssocResult($sql);
		
} else {
	echo 'Параметры не переданы';
	exit;
}

//узнаем дату и действующие скидки
	$discount = discount();

if ($basket && $user) {
	$user = $user[0]['id'];
	
	foreach ($basket as $good) {
		$details .= "" . $good['name'] . " - " . $good['count'] . " шт.; ";
		
		if ($discount > 0) {
				
				$newPrice = $good['price'] - ($good['price'] * $discount / 100);
				$total += $newPrice *  $good['count'];
				
			} else {
			
			$total += $good['price'] *  $good['count'];
			
			}
	}
		
	if (!empty($details) && $total > 0) {
		$sql = "INSERT INTO `orders`(`id_user`, `status`, `sum`, `date`, `details`) VALUES ('$user', '1', '$total', '$date', '$details')";
		$result = executeQuery($sql);
	}
	
} else {
	echo 'Корзина пустая';
	exit;
}

if ($result) {
	$sql = "DELETE FROM `basket_" . $userName . "`";
	$result_1 = executeQuery($sql);
} else {
	echo 'Заказ не создан';
	exit;
}

if ($result_1) {
	echo 'Заказ создан';
} else {
	echo 'Произогла ошибка';
	exit;
}
?>