<?php
require_once('../config/config.php');

echo render(TPL_DIR . 'template.tpl',
			['title' => 'Заказы ', 'h1' => 'Мои заказы'], 'myOrders.php'
		   );
?>