<?php
require_once('../config/config.php');

if (!empty($_POST['userName']) && !empty($_POST['userMail']) && !empty($_POST['review'])) {
	
	$userName = $_POST['userName'];
	$userMail = $_POST['userMail'];
	$review = $_POST['review'];
	$date = date('Y-m-d');
	
	$alert_text = addNewComment($userName, $userMail, $review, $date);
} else {
	$alert_text = 'Заполните форму';
}

echo render(TPL_DIR . 'template.tpl', ['title' => 'Отзывы ', 'h1' => 'Отзывы', 'scripts' => '<script>alert("' . $alert_text . '");</script>'], 'comments.php');

?>