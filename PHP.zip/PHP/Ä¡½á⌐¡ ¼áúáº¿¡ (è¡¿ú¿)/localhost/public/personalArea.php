<?php
require_once('../config/config.php');

echo render(TPL_DIR . 'template.tpl',
			['title' => 'Личный кабинет',
			 'link' => '<link rel="stylesheet" href="css/login.css"><link rel="stylesheet" href="css/style.css">',
			 'h1' => 'Личный кабинет',
			 'scripts' => '<script src="js/scripts.js"></script>'],
			 'personalArea.php'
		   );

?>