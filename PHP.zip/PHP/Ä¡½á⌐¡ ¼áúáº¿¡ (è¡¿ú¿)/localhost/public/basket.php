<?php
require_once('../config/config.php');

echo render(TPL_DIR . 'template.tpl',
			['title' => 'Корзина товаров',
			 'link' => '<link rel="stylesheet" href="css/login.css"><link rel="stylesheet" href="css/style.css">',
			 'h1' => 'Корзина',
			 'scripts' => '<script src="js/scripts.js"></script>'],
			 'basket.php'
		   );
?>