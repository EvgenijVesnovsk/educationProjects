<?php
require_once('../config/config.php');

$id = '';
$sql = '';
$result = '';

if (!empty($_POST['id'])) {
	$id = $_POST['id'];
	$sql = "DELETE FROM `orders` WHERE `id` = '$id'";
	$result = executeQuery($sql);
} else {
	echo "Идентификатор не передан.";
	exit;
}
	
if ($result) {
	echo "true";
} else {
	echo "Произошла ошибка.";
	exit;
}
?>