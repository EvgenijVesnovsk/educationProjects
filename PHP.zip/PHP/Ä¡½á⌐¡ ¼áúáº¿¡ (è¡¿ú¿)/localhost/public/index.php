<?php
require_once('../config/config.php');

echo render(TPL_DIR . 'template.tpl',
			['title' => 'Интернет-магазин Книг ', 'h1' => 'Каталог товаров'], 'index.php'
		   );
?>