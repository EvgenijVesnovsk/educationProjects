﻿$('.user').click(function(){
	$('#overlay').fadeIn(400, function(){ 
		$('#modal_form_unregistered')
		.css('display', 'block') 
		.animate({opacity: 1}, 200); 
					
		var $login_input = $('[name="login"]');
		var $password_input = $('[name="password"]');
			
//		событие клика по кнопке ВОЙТИ в форме
		$('.enter').click(function(){
						
			var login = $login_input.val();
			var password = $password_input.val();
						
			$.post({
				url: 'login.php',
				data: {login: login,
					password: password},
				success: function (response) {
					console.log('tyt');
					console.log(response);
				if (response === 'true') {
					location.pathname = 'personalArea.php';
					} else {
					$('.modal_form__body')
					  .prepend('<p class="error">' + response + '</p>');
					}
					setTimeout(function() { $(".error").hide('slow'); }, 2000);
				},
				error: function( xhr, textStatus ) {
					console.log([ xhr.status, textStatus ]);
				}
				});
		});
		
		$('.registration').click(function(){
			$('#modal_form_unregistered')
			.animate({opacity: 0}, 200,  // плaвнo меняем прoзрaчнoсть нa 0 и oднoвременнo двигaем oкнo вверх
			function(){ // пoсле aнимaции
				$(this).css('display', 'none'); // делaем ему display: none;
			});
			
			$('#modal_form_registration')
			.css('display', 'block') 
			.animate({opacity: 1}, 200);
				
//		событие клика по кнопке ВОЙТИ в форме
//			$('.goRegistration').click(function(){
//				
//			var $login_input = $('[name="login"]');
//			var $password_input = $('[name="password"]');
//			var $userName_input = $('[name="userName"]');
//			var $mail_input = $('[name="mail"]');
//				
////			console.log($login_input[0], $password_input[0]);
//						
//			var login = $login_input.val();
//			var password = $password_input.val();
//			var userName = $userName_input.val();
//			var mail = $mail_input.val();
//										
//			$.post({
//				url: 'registration.php',
//				data: {login: login,
//					   password: password,
//					   userName: userName,
//					   mail: mail},
//				success: function (response) {
//				if (response === 'true') {
//						location.reload();
//					} else {
//					$('.modal_form__body')
//					  .prepend('<p class="error">' + response + '</p>');
//					}
//					setTimeout(function() { $(".error").hide('slow'); }, 2000);
//				},
//				error: function( xhr, textStatus ) {
//					console.log([ xhr.status, textStatus ]);
//				}
//			});
//		});
		});
	});
});

$('.userReg').click(function(){
	$('#overlay').fadeIn(400, function(){ 
		$('#modal_form_registered')
		.css('display', 'block') 
		.animate({opacity: 1}, 200); 
	});
});

$('#overlay').click( function(){ // лoвим клик пo крестику или пoдлoжке
	$('#modal_form_registered, #modal_form_unregistered, #modal_form_registration')
		.animate({opacity: 0}, 200,  // плaвнo меняем прoзрaчнoсть нa 0 и oднoвременнo двигaем oкнo вверх
			function(){ // пoсле aнимaции
				$(this).css('display', 'none'); // делaем ему display: none;
				$('#overlay').fadeOut(400); // скрывaем пoдлoжку
			}
		);
});

$('.aminLi').mouseenter(function() {
	$('.under_Menu')
	.css('display', 'block')
	.animate({opacity: 1}, 200); ;
});

$('.aminLi').mouseleave(function() {
	$('.under_Menu')
	.css('display', 'none')
	.animate({opacity: 0}, 200); ;
});


//удаление заказа пользователем
$('.deleteOrder').click(function(event){
	var order = event.target;
	var id = order.getAttribute('data-id');
	
	$.post({
			url: 'deleteOrder.php',
			data: {id: id},
			success: function (response) {
				if (response === 'true') {
					$('.orders[data-id="' + id + '"]').remove();
					}
			},
			error: function( xhr, textStatus ) {
				console.log([ xhr.status, textStatus ]);
			}
	});
	
});

$('.toSend').click(function(event){
	var order = event.target;
	var id = order.getAttribute('data-id');
	
	$.post({
			url: 'toSend.php',
			data: {id: id},
			success: function (response) {
				if (response === 'true') {
					$('.orderStatus[data-id="' + id + '"]').html('В обработке');
					$('.toSend[data-id="' + id + '"]').html('');
					}
			},
			error: function( xhr, textStatus ) {
				console.log([ xhr.status, textStatus ]);
			}
	});
	
});