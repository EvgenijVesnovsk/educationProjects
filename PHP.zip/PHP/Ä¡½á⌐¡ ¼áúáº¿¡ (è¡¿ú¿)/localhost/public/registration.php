<?php
require_once('../config/config.php');

$error = false;
$alert = "";
$result = '';
$mail = '';
$login = '';
$city = '';
$sql = '';
$users = '';


if (!empty($_POST)) {
	
	if(empty($_POST['userName'])) {
		$alert .= 'Введите Ваше имя. ';
		$error = true;
		echo $alert;
		exit;
	}
	
	if(empty($_POST['login'])) {
		$alert .= 'Введите логин. ';
		$error = true;
		echo $alert;
		exit;
	}
	
	if(empty($_POST['password'])) {
		$alert .= 'Введите пароль. ';
		$error = true;
		echo $alert;
		exit;
	}
	
	if(empty($_POST['mail'])) {
		$alert .= 'Введите почту. ';
		$error = true;
		echo $alert;
		exit;
	}
	
	if(empty($_POST['city'])) {
		$alert .= 'Выберите город. ';
		$error = true;
		echo $alert;
		exit;
	}
	
} else {
	$alert = 'Параметры не переданы. ';
	$error = true;
	echo $alert;
	exit;
}

//проверяем есть ли пользователь с такой же почтой и логином
if (!$error) {
	
	$mail = $_POST['mail'];
	$login = $_POST['login'];
	$city = $_POST['city'];
	
	$sql = "SELECT * FROM `users`";
	$users = getAssocResult($sql);
	
	foreach($users as $user) {
		if ($user['mail'] === $mail) {
			$alert .= 'Уже есть пользователь с таким email. ';
			$error = true;
			echo $alert;
			exit;
		}
		if ($user['login'] === $login) {
			$alert .= 'Уже есть пользователь с таким логином. ';
			$error = true;
			echo $alert;
			exit;
		}
	}
}

//создаем нового пользователя
if (!$error) {
	
	$userName = $_POST['userName'];
	$password = md5($_POST['password']);
	
	$sql = "INSERT INTO `users`(`name`, `login`, `password`, `mail`, `city`, `is_admin`) VALUES ('$userName', '$login', '$password', '$mail', '$city', '0')";
	$result = executeQuery($sql);
} 

//создаем корзину товаров для нового пользователя
if ($result) {
				
	$sql = "CREATE TABLE `geek_brains_shop`.`basket_" . $login . "` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NULL , `price` INT NULL , `count` TINYINT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";
	$result_1 = executeQuery($sql);

} else {
	$alert .= 'Пользователь не создан. ';
	echo $alert;
	exit;
};

if ($result_1) {
	$alert .= 'true';
	header('Location: index.php');
} else {
	$alert .= 'Корзина не создана. ';
	echo $alert;
	exit;
}

echo $alert;
?>