<?php
require_once('../config/config.php');

echo render(TPL_DIR . 'template.tpl', ['title' => 'Интернет-магазин Книг. Карточка товара ', 'h1' => 'Подробное описание товара'], 'goods_item.php');
?>