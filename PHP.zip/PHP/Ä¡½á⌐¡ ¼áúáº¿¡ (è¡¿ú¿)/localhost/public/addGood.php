<?php
require_once('../config/config.php');

	$id = '';
	$error = false;
	$alert = '';
	$sql = '';
	$result = '';
	$name = '';
	$price = '';
	$result_1 = '';
	

//if (!empty($_GET['id'])) {
//	//создаем новую таблицу(корзину) в БД для нового пользователя
//		
//	$id = $_GET['id'];
//	$userName = $_SESSION['user']['login'];
//	
//	$sql = "CREATE TABLE `geek_brains_shop`.`basket_" . $userName . "` ( `id` INT NOT NULL AUTO_INCREMENT , `name` VARCHAR(255) NULL , `price` TINYINT NULL , `count` TINYINT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;";
//	$result = executeQuery($sql);
//	
//} else {
//	$alert = 'Идентификатор товара не передан';
//}



//если таблица(корзина) создана
//if ($result) {

if (!empty($_GET['id'])) {
	$id = $_GET['id'];
	$userName = $_SESSION['user']['login'];
	$sql = "SELECT * FROM `goods` WHERE `id` = '$id'";
	$good = getAssocResult($sql);
} else {
	$alert = 'Идентификатор товара не передан';
}
//} else {
//	$alert = 'Таблица не создана';	
//}

//если товар найден в списке

if (!empty($good)) {
	$name = $good[0]['name'];
	$price = $good[0]['price'];
	
	//проверяем перед добавлением есть ли такой товар уже в корзине
		//если есть, то увеличиваем количество на 1
	
	$sql = "SELECT * FROM `basket_" . $userName . "`";
	$basket_1 = getAssocResult($sql);
	
	foreach ($basket_1 as $good) {
		if ($name === $good['name']) {
			$sql = "UPDATE `basket_" . $userName . "` SET `count` = `count` + 1";
			$result_1 = executeQuery($sql);  //true
		}
	}
	
		//если нет, то вставляем новую строчку
		
	if (!$result_1) {
		$sql = "INSERT INTO `basket_" . $userName . "`(`name`, `price`, `count`) VALUES ('$name','$price','1')";
		$result_1 = executeQuery($sql); //true
	}
} else {
	$alert = 'Товар не найден';	
}


if ($result_1) {
	$alert = 'Товар успешно добавлен';	
} else {
	$alert = 'Произошла ошибка';	
}

echo $alert;

?>