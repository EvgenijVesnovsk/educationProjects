<?php
require_once('../../config/configAdmin.php');

$id = '';
$sql = '';
$result = '';

if (!empty($_POST['id'])) {
	$id = $_POST['id'];
	$sql = "UPDATE `orders` SET `status`='2' WHERE id='$id'";
	$result = executeQuery($sql);
} else {
	echo "Идентификатор не передан.";
	exit;
}
	
if ($result) {
	echo "true";
} else {
	echo "Произошла ошибка.";
	exit;
}
?>