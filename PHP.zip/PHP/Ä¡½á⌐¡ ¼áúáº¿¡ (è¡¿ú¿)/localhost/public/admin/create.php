<?php
require_once('../../config/configAdmin.php');

$error = false;
$alert_text = '';

if(!empty($_POST)) {

	//	проверки
	
	if (empty($_POST['title'])) {
		$error = true;
		$alert_text .= 'Введите название. ';
	}
	
	if (empty($_POST['description'])) {
		$error = true;
		$alert_text .= 'Введите описаниею ';	
	}
	
	if (empty($_POST['price']) || $_POST['price'] <= 0) {
		$error = true;
		$alert_text .= 'Введите цену больше нуля. ';	
	}
	
} else {
	$error = true;
	$alert_text .= 'Заполните форму. ';	
}

if(!$error) {

	// проверка загрузки изображений
	if ($_FILES['image']['tmp_name']) {

		$uploaddir = WWW_ROOT . '/img/catalog/';
		$image = basename($_FILES['image']['name']);
		$uploadfile = $uploaddir . $image;
		
		//проверка на дубликат
		if (!is_file($uploadfileSmall)) {

			if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
				$alert_text .= "Изображение корректно и было успешно загружено. ";
			} else {
				$error = true;
				$alert_text .= "Возможная атака с помощью файловой загрузки! Изображение не загружено. ";
			}

		} else {
			$error = true;
			$alert_text .= "Такое имя для изображения уже занято. Попробуйте придумать другое. ";
		};

	} else {
		$error = true;
		$alert_text .= "Выберите изображение. ";
	}
}

if(!$error) {
	
	$result = '';
	
	$db_link = getConnection();
	
	$title = prepareSqlString($db_link, $_POST['title']);
    $description = prepareSqlString($db_link, $_POST['description']);
    $price = prepareSqlString($db_link, $_POST['price']);
	$src = 'img/catalog/' . $image;
	$is_active = '1';
		
	/* запрос в базу */
	$sql = "INSERT INTO `goods` (`name`, `description`, `price`, `src`, `is_active`) VALUES ('$title', '$description', '$price', '$src', '$is_active')";
	$result = executeQuery($sql);
	
	if ($result) {
		$alert_text .= 'Успешно создано';	
	} else {
		$alert_text .= 'Произошла ошибка';	
	}
}

echo $alert_text;
echo render(TPL_DIR . 'admin.tpl', ['title' => 'Интернет-магазин Книг ', 'h1' => 'Добавить товар'], 'admin/create.php');

?>