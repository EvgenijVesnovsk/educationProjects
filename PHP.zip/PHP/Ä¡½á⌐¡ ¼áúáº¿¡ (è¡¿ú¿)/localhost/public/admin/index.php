<?php
require_once('../../config/configAdmin.php');

echo render(TPL_DIR . 'admin.tpl', ['title' => 'Интернет-магазин Книг ', 'h1' => 'Каталог товаров'], 'admin/index.php');
?>