<?php
require_once('../../config/configAdmin.php');

$id = $_GET['id'] ?? 0;

if(!$id) {
	$alert_text .= "Идентификатор товара не передан";
} else {
	
	$error = false;
	$alert_text = '';
	
	if ($_POST['title'] || $_POST['description'] || $_POST['price'] || $_FILES['imageSmall']['name'] || $_FILES['imageBig']['name']) {
		
		$goodItem = getAssocResult("SELECT * FROM `goods` WHERE id = '$id'");
		
	foreach ($goodItem as $good) {
		$title = $good['name'];
		$description = $good['description'];
		$price = $good['price'];
		$src = $good['src'];
	}
		
	$db_link = getConnection();	
		
	//проверка
	if(!empty($_POST['title'])) {	
		$title = prepareSqlString($db_link, $_POST['title']);
	}
		
	if(!empty($_POST['description'])) {
		$description = prepareSqlString($db_link, $_POST['description']);
	}
	
	if(!empty($_POST['price'])) {
		$price = prepareSqlString($db_link, $_POST['price']);
	}
	
	
	// проверка загрузки изображения
	if ($_FILES['image']['tmp_name']) {
		
		$uploaddir = WWW_ROOT . '/img/catalog/';
		$image = basename($_FILES['image']['name']);
		$uploadfile = $uploaddir . $image;
		
		if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
			$alert_text .= "Изображение корректно и было успешно загружено. ";
		} else {
			$error = true;
			$alert_text .= "Возможная атака с помощью файловой загрузки! Изображение не загружено. ";
		}
				
		if ($small_src !== 'img/catalog/' . $image) {
			// => у нового файла новое имя => удаляем старый файл
			if (unlink(WWW_ROOT . $src)) {
				//указываем путь к новому файлу
				$src = 'img/catalog/' . $image;
				$alert_text .= 'Старое изображение успешно удалено. ';
			} else {
				$alert_text .= 'Не удалось удалить старое изображение. ';
			}			
		}
	}
					
	if(!$error) {
		
		$result = '';

		$is_active = '1';
		
		/* запрос в базу */
		$sql = "UPDATE `goods` SET `name` = '$title', `description` = '$description', `price` = '$price', `src` = '$src', `is_active` = '$is_active' WHERE id = '$id'";
		$result = executeQuery($sql);

		if ($result) {
			$alert_text .= 'Успешно изменено';	
		} else {
			$alert_text .= 'Произошла ошибка';	
		}
	}
		
	} else {
		$error = true;
		$alert_text .= 'Заполните форму';	
	}
		
}

echo $alert_text;
echo render(TPL_DIR . 'admin.tpl', ['title' => 'Интернет-магазин Книг ', 'h1' => 'Редактировать товар'], 'admin/update.php?id=' . $id . '');
?>