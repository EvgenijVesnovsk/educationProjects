<?php
require_once('../../config/configAdmin.php');

$id = $_GET['id'] ?? 0;

if(!$id) {
	$alert_text .= "Идентификатор товара не передан";
	exit();
} else {
	
	//удаляем изображения товара
	$sql = "SELECT * FROM `goods` WHERE id = '$id'";
	$goods = getAssocResult($sql);
	foreach ($goods as $good) {
		$src = $good['src'];
	}
	
	if (unlink(WWW_ROOT . $src)) {
		$alert_text .= 'Изображение успешно удалено. ';
	} else {
		$alert_text .= 'Не удалось удалить изображение. ';
	}
	
	/* удаляем из базы*/
	$sql = "DELETE FROM `goods` WHERE id = '$id'";
	$result = executeQuery($sql);
	
	if ($result) {
		$alert_text .= 'Запись в БД успешно удалена. ';	
	} else {
		$alert_text .= 'При удалении записи из БД произошла ошибка. ';	
	}
}

echo $alert_text;
echo render(TPL_DIR . 'admin.tpl', ['title' => 'Интернет-магазин Книг ', 'h1' => 'Каталог товаров'], 'admin/index.php');

?>