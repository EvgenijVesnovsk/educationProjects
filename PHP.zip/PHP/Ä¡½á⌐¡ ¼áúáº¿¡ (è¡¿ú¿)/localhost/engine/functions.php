<?php

define('SERVER_TIME_GMT', 10800);

//Константы ошибок
define('ERROR_NOT_FOUND', 1);
define('ERROR_TEMPLATE_EMPTY', 2);

/*
* Обрабатывает указанный шаблон, подставляя нужные переменные
*/
function render($file, $variables = [], $page)
{
    if (!is_file($file)) {
        echo 'Template file "' . $file . '" not found';
        exit(ERROR_NOT_FOUND);
    }

    if (filesize($file) === 0) {
        echo 'Template file "' . $file . '" is empty';
        exit(ERROR_TEMPLATE_EMPTY);
    }

    // если переменных для подстановки не указано, просто
    // возвращаем шаблон как есть
    if (empty($variables)) {
        $templateContent = file_get_contents($file);
    } else {
        $templateContent = file_get_contents($file);
        foreach ($variables as $key => $value) {
            if ($value != null) {
                // собираем ключи
                $key = '{{' . strtoupper($key) . '}}';

                // заменяем ключи на значения в теле шаблона
                $templateContent = str_replace($key, $value, $templateContent);
            }
        }
		//генерируем и подставляем меню контент
		
		$pieces = explode("?", $page);
		
		$templateContent = str_replace('{{MENU}}', createMenu($page, $pieces[1]), $templateContent);
		
		$templateContent = str_replace('{{MODALFORM}}', createModalForm(), $templateContent);
		
		switch($page) {
			case 'index.php':
			case 'admin/index.php':
				$templateContent = str_replace('{{CONTENT}}', makeCatalog($page), $templateContent);
				break;
			case 'goods_item.php':
				$templateContent = str_replace('{{CONTENT}}', makeGoodItem(), $templateContent);
				break;
			case 'comments.php':
				$templateContent = str_replace('{{CONTENT}}', makeComments(), $templateContent);
				break;
			case 'basket.php':
				$templateContent = str_replace('{{CONTENT}}', createBasket(), $templateContent);
				break;	
			case 'personalArea.php':
				$templateContent = str_replace('{{CONTENT}}', createPersonalArea(), $templateContent);
				break;
			case 'myOrders.php':
				$templateContent = str_replace('{{CONTENT}}', createMyOrders(), $templateContent);
				break;
			case 'admin/create.php':
				$templateContent = str_replace('{{CONTENT}}', createItem(), $templateContent);
				break;
			case 'admin/orders.php':
				$templateContent = str_replace('{{CONTENT}}', createOrders(), $templateContent);
				break;
			default:
				$templateContent = str_replace('{{CONTENT}}', updateItem($pieces[1]), $templateContent);
				break;	
		}
		
    }
    return $templateContent;
}

function createMyOrders() {
	$str = '';
	$userId = '';
	$sql = '';
	$orders = '';
	
	if(!empty($_SESSION['user'])) {
		$userId = $_SESSION['user']['id'];
		$sql = "SELECT * FROM `orders` WHERE `id_user` = '$userId'";
		$orders = getAssocResult($sql);
	}
	
	if (!empty($orders)) {
		foreach ($orders as $order) {
			
			switch ($order['status']) {
				case '1':
					$status = 'Ждет обработки';
					break;
				case '2':
					$status = 'В обработке';
					break;
				case '3':
					$status = 'Отправлен';
					break;
				default:
					$status = 'Доставлен';
			}
			
			$str .= '<p class="orders" data-id="' . $order['id'] . '">Номер заказа: ' . $order['id'] . '<br><br>
			Заказ: ' . $order['details'] . '<br><br>
			Сумма: ' . $order['sum'] . '<br><br>
			Дата: ' . $order['date'] . '<br><br>
			Статус: ' . $status . '<br><br>';
			if ($status === 'Ждет обработки') {
				$str .= '<span class="deleteOrder" data-id="' . $order['id'] . '">Отменить</span>';
			}
			$str .= '</p>';
		}
	} else {
		$str .= 'Заказов нет';
	}
	
	return $str;
	
	

	
	return $str;
}

function createOrders() {
	
	$str = '';
	$sql = "SELECT * FROM `orders`";
	$orders = '';
	$status = '';
	
	$orders = getAssocResult($sql);
	
	if (!empty($orders)) {
		foreach ($orders as $order) {
			
			switch ($order['status']) {
				case '1':
					$status = 'Новый заказ';
					break;
				case '2':
					$status = 'В обработке';
					break;
				case '3':
					$status = 'Отправлен';
					break;
				default:
					$status = 'Доставлен';
			}
			
			$str .= '<p class="toSendOrders">Номер заказа: ' . $order['id'] . '<br><br>
			Заказ: ' . $order['details'] . '<br><br>
			Сумма: ' . $order['sum'] . '<br><br>
			Дата: ' . $order['date'] . '<br><br>
			<span class="orderStatus" data-id="' . $order['id'] . '">Статус: ' . $status . '</span><br><br>';
			if ($status === 'Новый заказ') {
				$str .= '<span class="toSend" data-id="' . $order['id'] . '">Принять</span>';
			}
			$str .= '</p>';
		}
	} else {
		echo 'Заказов нет';
	}
	
	return $str;
}

function createPersonalArea() {
	
	$str = '';
	$alert = '';
	
	if(!empty($_SESSION['user'])) {
		$str .= '<p>Добро пожаловать, ' . $_SESSION['user']['name'] . '</p>';
		$str .= '<p>Имя: ' . $_SESSION['user']['name'] . '<br><br>Логин: ' . $_SESSION['user']['login'] . '</p>';
	} else {
		$alert = 'Пользователь не определен';
		return $alert; 
	}
	
	return $str;
	
}

//корзина товаров
function createBasket() {
	
	$sql = '';
	$alert = '';
	$basket = '';
	$str = '';
	$total = 0;
	
	//узнаем дату и действующие скидки
	$discount = discount();

	if(!empty($_SESSION['user'])) {
		$userName = $_SESSION['user']['login'];
		$sql = "SELECT * FROM basket_" . $userName . "";
		$basket = getAssocResult($sql);
	} else {
		$alert = 'Пользователь не определен';
		return $alert; 
	}

	if ($basket) {
		foreach ($basket as $good) {
			$str .= "<p class='goodInBasket'>" . $good['name'] . "<br><br>";
			
			if ($discount > 0) {
				
				$newPrice = $good['price'] - ($good['price'] * $discount / 100);
				
				$str .= 'Старая цена: ' . $good['price'] . ' &#8381;<br><br>';	
				$str .= 'Цена со скидкой: ' . $newPrice . ' &#8381;';
				
				$total += $newPrice *  $good['count'];
				
			} else {
				
				$str .= '' . $good['price'] . ' &#8381;';
				
				$total += $good['price'] *  $good['count'];
			}
				$str .= "<br><br>Количество: " . $good['count'] . "<br><br><a href='deleteGood.php?id=" . $good['id'] . "'>Удалить</a></p>";	
			
		}
		
		$str .= '<p>Сумма заказа: ' . $total . '   <a class="order" href="makeOrder.php?userName=' . $userName . '">Заказать</a></p>';
	} else {
		$alert = 'В корзине нет товаров.';
		return $alert; 
	}
	
	return $str;
	
}

function createModalForm() {
	
	if (!empty($_SESSION['user'])) {
		
		$str .= '<div id="modal_form_registered">';
		
			$str .= '<ul>';
		
			if ($_SESSION['user']['login'] !== 'admin') {
				$str .= '<li><a href="personalArea.php">Личный кабинет</a></li>';
				$str .= '<li><a href="basket.php">Корзина</a></li>';
				$str .= '<li><a href="myOrders.php">Заказы</a></li>';
			};
				$str .= '<li><a href="logout.php">Выход</a></li>';
			$str .= '</ul>';	
		
		$str .= '</div>';
		
	} else {
		
		$str .= '<div id="modal_form_unregistered">';
			$str .= '<div class="modal_form__header">';
				$str .= '<h2>ВОЙТИ</h2>';
			$str .= '</div>';
			$str .= '<div class="modal_form__body">';
				$str .= '<form>';
//				$str .= '<form action="login.php" method="post">';
					$str .= '<p>Логин: <input type="text" name="login"></p>';
					$str .= '<p>Пароль: <input type="password" name="password"></p>';
					$str .= '<p><input type="button" class="enter" value="Войти"></p>';
//					$str .= '<p><input type="submit" value="Войти"></p>';
					$str .= '<p><input type="button" class="registration" value="Зарегистрироваться"></p>';
				$str .= '</form>';
			$str .= '</div>';
		$str .= '</div>';
		
		$str .= '<div id="modal_form_registration">';
			$str .= '<div class="modal_form__header">';
				$str .= '<h2>РЕГИСТРАЦИЯ</h2>';
			$str .= '</div>';
			$str .= '<div class="modal_form__body">';
				$str .= '<form action="registration.php" method="post">';
//				$str .= '<form>';
					$str .= '<p>Имя: <input type="text" name="userName" required></p>';
					$str .= '<p>Логин: <input type="text" name="login" required></p>';
					$str .= '<p>Пароль: <input type="password" name="password" required></p>';
					$str .= '<p>Mail: <input type="text" name="mail" required></p>';
					$str .= '<p>Город: <select name="city" required>
								<option disabled selected>Выберите город</option>
								<option value="Москва">Москва</option>
								<option value="Санкт-Петербург">Санкт-Петербург</option>
								<option value="Новороссийск">Новороссийск</option>
								<option value="Владивосток">Владивосток</option>
						   	</select></p>';
					$str .= '<p><input type="submit" class="goRegistration" value="Зарегистрироваться"></p>';
//					$str .= '<p><input type="button" class="goRegistration" value="Зарегистрироваться"></p>';
				$str .= '</form>';
			$str .= '</div>';
		$str .= '</div>';
		
	}
	
	$str .= '<div id="overlay">';
	$str .= '</div>';
	
	return $str;
}

function makeComments() {
	
	$reviews = getReviews();

	foreach ($reviews as $review) {
		$str .= 'Имя: <span class="userColor">' . $review['fio'] . '</span><br>';
		$str .= '<p class="comment">' . $review['text'] . '</p>';
	}
	
	$str .= '<h2>Добавить отзыв</h2>';
	$str .= '<form enctype="multipart/form-data" action="comments.php" method="POST">';
	$str .= 'Имя: <input type="text" name="userName" cols="50" placeholder="Ваше имя:" required><br><br>';
	$str .= 'Почта: <input type="text" name="userMail" cols="50" placeholder="Ваш e-mail:" required><br><br>';
	$str .= '<textarea name="review" cols="100" rows="10" style="resize: none;" placeholder="Напишите отзыв:" required></textarea><br>';
	$str .= '<p><input type="submit" value="Отправить"></p>';
	$str .= '</form>';
	
	return $str;
}

function updateItem($id) {
	
	$str = '';
	$sql = "SELECT * FROM `goods` WHERE $id";
	$goods = '';
	
	$goods = getAssocResult($sql);
	
	if (!empty($goods)) {
		$name = $goods[0]['name'];
		$description = $goods[0]['description'];
		$price = $goods[0]['price'];
		
		$str = '<form enctype="multipart/form-data" action="update.php?' . $id . '" method="POST">';
		$str .= '<p>Введите название:</p><input type="text" name="title" cols="100" value="' . $name . '"><br>';
		$str .= '<p>Введите описание:</p><textarea name="description" cols="100" rows="10" style="resize: none;" placeholder="Описание:">' . $description .'</textarea><br>';
		$str .= ' <input type="hidden" name="MAX_FILE_SIZE" value="300000" />';
		$str .= '<p>Загрузите изображение:</p><input type="file" name="image"><br>';
		$str .= '<p>Введите цену (руб.):</p><input type="number" name="price" cols="50" value="' . $price . '">';
		$str .= '<p><input type="submit" value="Отправить"></p>';
	$srt .= '</form>';
		
	} else {
		$str .= 'Товар не найден';
	}
	
	return $str;
}

function createMenu($page, $pieces) {
	
	$str = '<ul class="menu">';
	
	if ($page !== 'admin/index.php' && $page !== 'admin/create.php' && $page !== 'admin/update.php?' . $pieces . '' && $page !== 'admin/orders.php') {
				
		//если пользователь - администратор
		if ($_SESSION['user']['is_admin'] === '1') {
			$str .= '<li><a href="index.php">Главная</a></li>';
			$str .= '<li><a href="comments.php">Отзывы</a></li>';
			$str .= '<li><a href="admin/index.php">Админка</a></li>';
		} else {
		//если пользователь - покупатель
			$str .= '<li><a href="index.php">Главная</a></li>';
			$str .= '<li><a href="comments.php">Отзывы</a></li>';
		}
		
		$str .= '</ul>';
		
		//если пользователь авторизирован, то вывести его имя
	
		if (!empty($_SESSION['user'])) {
			$str .= '<div class="userReg">';
			$str .= '<a href="#">' . $_SESSION['user']['name'] . '</a>';	
		} else {
			$str .= '<div class="user">';
			$str .= '<a href="#">Войти</a>';	
		}

		$str .= '</div>';
		
	} else {
		
		$str .= '<li><a href="../index.php">Главная</a></li>';
		$str .= '<li><a href="index.php">Редактировать товар</a></li>';
		$str .= '<li><a href="create.php">Добавить товар</a></li>';
		$str .= '<li><a href="orders.php">Заказы</a></li>';
		$str .= '</ul>';
	}
		
	return $str;
}

function createItem() {
	
	$str = '<form enctype="multipart/form-data" action="create.php" method="POST">';
		$str .= '<p>Введите название:</p><input type="text" name="title" cols="50" placeholder="Название:"><br>';
		$str .= '<p>Введите описание:</p><textarea name="description" cols="100" rows="10" style="resize: none;" placeholder="Описание:"></textarea><br>';
		$str .= ' <input type="hidden" name="MAX_FILE_SIZE" value="300000" />';
		$str .= '<p>Загрузите изображение:</p><input type="file" name="image"><br>';
		$str .= '<p>Введите цену (руб.):</p><input type="number" name="price" cols="50" placeholder="Цена:">';
		$str .= '<p><input type="submit" value="Отправить"></p>';
	$srt .= '</form>';
	
	return $str;
}

function makeGoodItem() {
	
	//узнаем дату и действующие скидки
	$discount = discount();
	
	if (isset($_GET['id'])) {
		
		$id = $_GET['id'];
		
		$goodItem = getAssocResult("SELECT `name`,`description`, `price`, `src`, `is_active` FROM `goods` WHERE id = '$id'");
		
		foreach ($goodItem as $good) {
			
			$str = '<div>';
				$str .= '<img class="goodItem" src="' . $good['src'] . '" alt="">';
				$str .= '<h2>' . $good['name'] . '</h2>';
			
				if ($discount > 0) {
					$newPrice = $good['price'] - ($good['price'] * $discount / 100);
					$str .= '<p>Старая цена: ' . $good['price'] . ' &#8381;</p>';	
					$str .= '<p>Цена со скидкой: ' . $newPrice . ' &#8381;</p>';	
				} else {
					$str .= '<p>' . $good['price'] . ' &#8381;</p>';	
				}
			
				$str .= '<p>' . $good['description'] . ';</p>';
			if ($good['is_active'] == 1) {
				$str .= '<p>В наличии: <img src="img/active.png" alt="active"></p>';
			} else {
				$str .= '<p>В наличии: <img class="is_active" src="img/no_active.png" alt="no_active"></p>';
			}
			$str .= '</div>';	
			
		}
			
		return $str;
		
	} else {
		echo "Произошла ошибка";
		exit();
	};
	
	
}

function discount() {
	
	//если пользователь зарегистрирован => узнаем его город нахождения
	if(!empty($_SESSION['user'])) {
		$userCity = $_SESSION['user']['city'];
		
		$sql = "SELECT * FROM `city` WHERE `name` = '$userCity'";
		$cities = getAssocResult($sql);
	} else {
		return 0;
	}
	
	//определяем разницу по времени
	if (!empty($cities)) {
				
		$serverTime = time(); //время на сервере
		
		$userTime = $serverTime + ((int)$cities[0]['UTC'] * 60 * 60 - SERVER_TIME_GMT); //время пользователя в зависимости от часового пояса(города)
		
		$date = date('d',$userTime); //дата пользователя
				
	} else {
		return 0;
	}
			
	$sql = "SELECT * FROM `discount`";
	$discounts = getAssocResult($sql);
		
	if (!empty($discounts)) {
		foreach ($discounts as $discount) {
			if ($date == $discount['day']) {
				return $discount['discount'];
			}
		}
	} else {
		return 0;
	}
}

function makeCatalog($page) {
	$catalog = getAssocResult("SELECT * FROM `goods`");
	
	//узнаем дату и действующие скидки
	$discount = discount();
	
	$str = '<div class="catalog">';
	
	foreach ($catalog as $good) {
	
		$str .= '<div class="catalog_item">';
		
		// если зашел администратор
		if ($page === 'admin/index.php' && $_SESSION['user']['is_admin'] === '1') {
			$str .= '<a href="update.php?id=' . $good['id'] . '">Редактировать</a> <a href="delete.php?id=' . $good['id'] . '">Удалить</a>';
			$str .= '<a href="../goods_item.php?id=' . $good['id'] . '">';
		} else {
		// если зашел пользователь		
			if (!empty($_SESSION['user']) && $_SESSION['user']['is_admin'] !== '1') {
				$str .= '<a href="addGood.php?id=' . $good['id'] . '">Купить</a><br>';
			}
			$str .= '<a href="goods_item.php?id=' . $good['id'] . '">';
			
		}
		$str .= '<div class="src_small">';
		$str .= '<img src="../' . $good['src'] . '" alt="">';
		$str .= '</div></a><br>';
		$str .= '<p>' . $good['name'] . '</p>';
		
		if ($discount > 0) {
			$newPrice = $good['price'] - ($good['price'] * $discount / 100);
			$str .= '<p>Старая цена: ' . $good['price'] . ' &#8381;</p>';	
			$str .= '<p>Цена со скидкой: ' . $newPrice . ' &#8381;</p>';	
		} else {
			$str .= '<p>' . $good['price'] . ' &#8381;</p>';	
		}
		
		$str .= '</div>';
	}
	
	$str .= '</div>';

	return $str;
}

function getReviews(){
    $sql = "SELECT * FROM comments";
    $reviews = getAssocResult($sql);

    return $reviews;
}

function prepareSqlString($db_link, $string) {
	return mysqli_real_escape_string(
		$db_link,
		(string)htmlspecialchars(strip_tags($string))
	);
}

function addNewComment($userName, $userMail, $review, $date){
    $response = "";
    $db_link = getConnection();

    $feedback_user = prepareSqlString($db_link, $userName);
    $feedback_email = prepareSqlString($db_link, $userMail);
    $feedback_text = prepareSqlString($db_link, $review);
	
    $sql = "INSERT INTO `comments` (`fio`, `email`, `text`, `date`) VALUES ('$feedback_user', '$feedback_email', '$feedback_text', '$date')";
    $res = executeQuery($sql, $db_link);

    if(!$res)
        $response = "Произошла ошибка!";
    else
        $response = "Отзыв добавлен";

    return $response;
}

?>