-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 02 2019 г., 16:42
-- Версия сервера: 5.6.41
-- Версия PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `geek_brains_shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `basket_admin`
--

CREATE TABLE `basket_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(4) DEFAULT NULL,
  `count` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `basket_anna`
--

CREATE TABLE `basket_anna` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `count` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `basket_anton`
--

CREATE TABLE `basket_anton` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(4) DEFAULT NULL,
  `count` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `UTC` varchar(3) NOT NULL COMMENT 'Время по Гринвичу'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `city`
--

INSERT INTO `city` (`id`, `name`, `UTC`) VALUES
(1, 'Новороссийск', '+3'),
(2, 'Владивосток', '+10'),
(3, 'Москва', '+3'),
(4, 'Санкт-Петербург', '+3');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `fio` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `fio`, `email`, `text`, `date`) VALUES
(97, 'Костя', 'email@mail.ru', 'Привет', '0000-00-00'),
(99, 'Аня', 'email@mail.ru', 'Отличный сайт!', '0000-00-00');

-- --------------------------------------------------------

--
-- Структура таблицы `discount`
--

CREATE TABLE `discount` (
  `id` int(11) NOT NULL,
  `discount` tinyint(2) NOT NULL COMMENT '%',
  `day` tinyint(2) NOT NULL COMMENT 'День в месяце, когда действует скидка'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `discount`
--

INSERT INTO `discount` (`id`, `discount`, `day`) VALUES
(1, 20, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `src` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name`, `description`, `price`, `src`, `is_active`) VALUES
(1, 'Harry Potter and the Philosopher`s Stone\r\n', 'Harry Potter has never even heard of Hogwarts when the letters start dropping on the doormat at number four, Privet Drive. Addressed in green ink on yellowish parchment with a purple seal, they are swiftly confiscated by his grisly aunt and uncle. Then, on Harrys eleventh birthday, a great beetle-eyed giant of a man called Rubeus Hagrid bursts in with some astonishing news: Harry Potter is a wizard, and he has a place at Hogwarts School of Witchcraft and Wizardry.', '599.00', 'img/catalog/harry_potter_and_the_philosophers_stone.jpg', 1),
(2, 'PHP 7', '\"Рассмотрены основы языка PHP и его рабочего окружения в Windows, Mac OS X и Linux. Отражены радикальные изменения в языке PHP, произошедшие с момента выхода предыдущего издания: трейты, пространство имен, анонимные функции, замыкания, элементы строгой типизации, генераторы, встроенный Web-сервер и многие другие возможности. Приведено описание синтаксиса PHP 7, а также функций для работы с массивами, файлами, СУБД MySQL, memcached, регулярными выражениями, графическими примитивами, почтой, сессиями и т. д. Особое внимание уделено рабочему окружению: сборке PHP-FPM и Web-сервера nginx, СУБД MySQL, протоколу SSH, виртуальным машинам VirtualBox и менеджеру виртуальных машин Vagrant. Рассмотрены современные подходы к Web-разработке, система контроля версий Git, GitHub и другие бесплатные Git-хостинги, новая система распространения программных библиотек и их разработки, сборка Web-приложений менеджером Composer, стандарты PSR и другие инструменты и приемы работы современного PHP-сообщества. В третьем издании добавлены 24 новые главы, остальные главы обновлены или переработаны. На сайте издательства находятся исходные коды всех листингов.', '1073.00', 'img/catalog/php_7.jpg', 0),
(3, 'Изучаем PHP и MySQL', 'Вы хотите уметь создавать не только статичные, но и динамичные, связанные с базами данных сайты? Тогда вам не обойтись без знания РНР и MySQL. Эта книга является уникальным визуальным руководством, благодаря которому вы усвоите данные технологии максимально эффективно. Вы не только изучите теорию, но и наберетесь практического опыта, создав целый ряд приближенных к реальным проектов (от рейтинговой системы до сайта знакомств). Вы освоите в деле все важнейшие концепции программирования на РНР и под MySQL: верификацию форм, работу с сессиями, эффективные запросы к базе данных, операции с файлами и многое другое. . .', '935.00', 'img/catalog/izuchaem_php_i_mysql.jpg', 1),
(4, 'JavaScript. Подробное руководство. Шестое издание', 'Пятое издание бестселлера \"JavaScript. Подробное руководство\" полностью обновлено. Рассматриваются взаимодействие с протоколом HTTP и применение технологии Ajax, обработка XML-документов, создание графики на стороне клиента с помощью тега \"canvas\", пространства имен в JavaScript, необходимые для разработки сложных программ, классы, замыкания, Flash и встраивание сценариев JavaScript в Java-приложения. .Часть I знакомит с основами JavaScript. В части II описывается среда разработки сценариев, предоставляемая веб-броузерами. Многочисленные примеры демонстрируют, как генерировать оглавление HTML-документа, отображать анимированные изображения DHTML, автоматизировать проверку правильности заполнения форм, создавать всплывающие подсказки с использованием Ajax, как применять XPath и XSLT для обработки XML-документов, загруженных с помощью Ajax. Часть III - обширный справочник по базовому JavaScript (классы, объекты, конструкторы, методы, функции, свойства и константы, определенные в JavaScript 1.5 и ECMAScript v3). Часть IV - справочник по клиентскому JavaScript (API веб-броузеров, стандарт DOM API Level 2 и недавно появившиеся стандарты: объект XMLHttpRequest и тег \"canvas\")', '1650.00', 'img/catalog/javascript-podrobnoe-rukovodstvo-shestoe-izdanie.jpg', 1),
(5, 'World of Warcraft. Перед бурей\r\n', 'События романа \"Перед Бурей\" происходят после кульминации сюжета обновления \"Тени Аргуса\". Эта история расскажет о том, что ожидает героев Орды и Альянса после их противостояния Пылающему Легиону.', '391.00', 'img/catalog/world-of-warcraft-pered-burej.jpg', 1),
(6, 'Гравити Фолз. Дневник 3', 'Гравити Фолз. Дневник 3 - книга, которая фигурирует в мультфильме. Авторская разработка самого создателя мультсериала! Книга раскрывает секреты городка Гравити Фолз и другие загадки, не раскрытые в мульфильме.', '1333.00', 'img/catalog/graviti-folz-dnevnik-3.jpg', 1),
(7, 'Тонкое искусство пофигизма: Парадоксальный способ жить счастливо', 'Современное общество пропагандирует культ успеха: будь умнее, богаче, продуктивнее — будь лучше всех. Соцсети изобилуют историями на тему, как какой-то малец придумал приложение и заработал кучу денег, статьями в духе «Тысяча и один способ быть счастливым», а фото во френдленте создают впечатление, что окружающие живут лучше и интереснее, чем мы. Однако наша зацикленность на позитиве и успехе лишь напоминает о том, чего мы не достигли, о мечтах, которые не сбылись. Как же стать по-настоящему счастливым? Популярный блогер Марк Мэнсон в книге «Тонкое искусство пофигизма» предлагает свой, оригинальный подход к этому вопросу. Его жизненная философия проста — необходимо научиться искусству пофигизма. Определив то, до чего вам действительно есть дело, нужно уметь наплевать на все второстепенное, забить на трудности, послать к черту чужое мнение и быть готовым взглянуть в лицо неудачам и показать им средний палец.\r\n', '449.00', 'img/catalog/tonkoe-iskusstvo-pofigizma-paradoksalnyj-sposob-zhit-schastlivo.jpg', 1),
(8, 'Зов Ктулху / The Call of Cthulhu', 'Говард Филлипс Лавкрафт является одним из самых влиятельных писателей двадцатого века. Его произведения смешивают фантазию и научную фантастику с хоррором, открывая дверь в обширную, тёмную вселенную, полную невообразимых миров и существ. В истории, положившей ей начало, рассказывается о древней сущности, спящей на дне океана; сущности, желающей вырваться, чтобы подчинить себе жизнь на планете. .Тексты произведений сокращены и адаптированы, снабжены грамматическим комментарием и словарем, в который вошли ВСЕ слова, содержащиеся в текстах. Благодаря этому книга подойдет для любого уровня владения английским языком.', '162.00', 'img/catalog/zov-ktulhu-the-call-of-cthulhu.jpg', 1),
(9, 'Богатый папа, бедный папа', 'Автор убежден, что в школе дети не получают нужных знаний о деньгах и потом всю жизнь работают ради денег, вместо того чтобы заставить деньги работать на себя. Углубленное изучение книги «Богатый папа, бедный папа» станет важным этапом вашего финансового обучения. В это обновленное издание включены существенные дополнения и материалы для семинарских занятий, которые помогут оптимизировать учебный процесс в соответствии с сегодняшними экономическими реалиями. Для широкого круга читателей.', '498.00', 'img/catalog/bogatyj-papa-bednyj-papa.jpg', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `small_src` varchar(255) DEFAULT NULL,
  `size` int(11) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 - новый заказ; 2- в обработке; 3 - отправлен; 4 - доставлен',
  `sum` float NOT NULL,
  `date` date NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `id_user`, `status`, `sum`, `date`, `details`) VALUES
(3, 5, 2, 254, '2018-12-31', 'Богатый папа, бедный папа - 1 шт.; Тонкое искусство пофигизма: Парадоксальный способ жить счастливо - 1 шт.; '),
(12, 5, 2, 935, '2019-01-01', 'Изучаем PHP и MySQL - 1 шт.; ');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `is_admin` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `login`, `password`, `mail`, `city`, `is_admin`) VALUES
(4, 'Евгений', 'admin', '4297f44b13955235245b2497399d7a93', 'e@mail.ru', 'Новороссийск', 1),
(5, 'Антон', 'anton', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'a@mail.ru', 'Москва', 0),
(7, 'Анна', 'anna', '4297f44b13955235245b2497399d7a93', 'anna@mail.ru', 'Владивосток', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `basket_admin`
--
ALTER TABLE `basket_admin`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `basket_anna`
--
ALTER TABLE `basket_anna`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `basket_anton`
--
ALTER TABLE `basket_anton`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `basket_admin`
--
ALTER TABLE `basket_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `basket_anna`
--
ALTER TABLE `basket_anna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `basket_anton`
--
ALTER TABLE `basket_anton`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT для таблицы `discount`
--
ALTER TABLE `discount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
