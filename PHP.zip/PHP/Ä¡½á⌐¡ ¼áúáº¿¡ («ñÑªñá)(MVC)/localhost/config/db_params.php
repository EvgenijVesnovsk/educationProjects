<?php

return [
        
    'host' => 'localhost',
    'dbname' => 'super_mag',
    'user' => 'root',
    'password' => '',
    
];